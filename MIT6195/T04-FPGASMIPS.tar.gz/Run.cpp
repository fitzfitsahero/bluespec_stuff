/*

Copyright (C) 2012

Arvind <arvind@csail.mit.edu>
Muralidaran Vijayaraghavan <vmurali@csail.mit.edu>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

#include <iostream>
#include <cstdio>
#include <unistd.h>

#include "SceMiHeaders.h"
#include "Memory.h"

Memory mem("../memory.vmh");

void fromCop(void* userdata, const Tuple2_Bit_5_Bit_32& resp)
{
  bool* finish = (bool*)userdata;
  if(resp.m_tpl_1.getByte(0) == 18) {
    std::cerr << resp.m_tpl_2.getWord(0);
  }
  else if(resp.m_tpl_1.getByte(0) == 19) {
    int x = resp.m_tpl_2.getWord(0);
    std::cerr << (char)x;
  }
  else if(resp.m_tpl_1.getByte(0) == 21) {
    (*finish) = true;
    if(resp.m_tpl_2.getWord(0) == 0)
      std::cerr << "PASSED\n";
    else
      std::cerr << "FAILED " << resp.m_tpl_2.getWord(0) << "\n";
  }
}

void fromMem(void* userdata, const Tuple2_MemPort_MemReq& req)
{
  InportQueueT<Tuple2_MemPort_Bit_32>* memResp = (InportQueueT<Tuple2_MemPort_Bit_32>*) userdata;
  if(req.m_tpl_2.m_op.m_val == req.m_tpl_2.m_op.e_Ld) {
    Tuple2_MemPort_Bit_32 resp;
    resp.m_tpl_1 = req.m_tpl_1;
    resp.m_tpl_2.setWord(0, mem.read(req.m_tpl_2.m_addr.getWord(0)));
    memResp->sendMessage(resp);
  }
  else {
    bool byteEn[4];
    for(int i = 0; i < 4; i++) {
      byteEn[i] = req.m_tpl_2.m_byteEn[i].getBit(0) == 1;
    }
    mem.write(req.m_tpl_2.m_addr.getWord(0), byteEn, req.m_tpl_2.m_data.getWord(0));
  }
}

int main()
{
  SceMiParameters params("scemi.params");
  SceMi* scemi(SceMi::Init(SceMi::Version(SCEMI_VERSION_STRING), &params));

  InportQueueT< BitT<32> > hostToCpu("", "scemi_inport", scemi);
  OutportProxyT<Tuple2_Bit_5_Bit_32> cpuToHost("", "scemi_outport", scemi);
  InportQueueT<Tuple2_MemPort_Bit_32> memResp("", "scemi_1_inport", scemi);
  OutportProxyT<Tuple2_MemPort_MemReq> memReq("", "scemi_1_outport", scemi);

  ShutdownXactor shutdown("", "scemi", scemi);

  volatile bool finish = false;
  cpuToHost.setCallBack(fromCop, (void*)&finish);
  memReq.setCallBack(fromMem, &memResp);
  SceMiServiceThread* sthread = new SceMiServiceThread(scemi);

  hostToCpu.sendMessage(0x1000);

  while (!finish) {
    sleep(1);
  }

  // Clean up
  shutdown.blocking_send_finish();
  sthread->stop();
  sthread->join();
  SceMi::Shutdown(scemi);
  delete sthread;

  return 0;
}
