#!/bin/bash

rm -f all.bsv
make clean &> /dev/null

for n in `seq 1 4` ; do
    echo "N = $n"
    if [ $n -ne 1 ] ; then
        echo "" >> all.bsv
        echo "" >> all.bsv
    fi
    echo "// =====================" >> all.bsv
    echo "// > cat Test$n.bsv" >> all.bsv
    echo "// =====================" >> all.bsv
    cat Test$n.bsv >> all.bsv
    echo "" >> all.bsv
    echo "// =====================" >> all.bsv
    echo "// > make N=$n" >> all.bsv
    echo "// =====================" >> all.bsv
    make N=$n 2>&1 | sed 's_^_// _' &>> all.bsv
    if [ $? -eq 0 ] ; then
        echo "" >> all.bsv
        echo "// =====================" >> all.bsv
        echo "// > ./sim$n" >> all.bsv
        echo "// =====================" >> all.bsv
        ./sim$n 2>&1 | sed 's_^_// _' &>> all.bsv
    fi
done
