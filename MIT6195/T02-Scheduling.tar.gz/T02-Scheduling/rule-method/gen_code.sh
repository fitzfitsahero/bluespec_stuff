#!/bin/bash

rm -f all.bsv
make clean &> /dev/null
tests=`cat order.txt`

for n in $tests ; do
    echo "N = $n"
    if [ $n != "1" ] ; then
        echo "" >> all.bsv
        echo "" >> all.bsv
    fi
    echo "// =====================" >> all.bsv
    echo "// > cat Test$n.bsv" >> all.bsv
    echo "// =====================" >> all.bsv
    cat Test$n.bsv >> all.bsv
    echo "" >> all.bsv
    echo "// =====================" >> all.bsv
    echo "// > make N=$n" >> all.bsv
    echo "// =====================" >> all.bsv
    make N=$n 2>&1 | sed 's_^_// _' &>> all.bsv
    echo "" >> all.bsv
    echo "// =====================" >> all.bsv
    echo "// > ./sim$n" >> all.bsv
    echo "// =====================" >> all.bsv
    ./sim$n 2>&1 | sed 's_^_// _' &>> all.bsv
done
