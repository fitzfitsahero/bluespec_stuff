//**************************************************************************
// Median filters
//--------------------------------------------------------------------------
// $Id: median.h,v 1.1.1.1 2006-02-20 03:54:52 cbatten Exp $

// Simple C version
void median( int n, int input[], int results[] );

// Simple assembly version
void median_asm( int n, int input[], int results[] );
