//**************************************************************************
// Software multiply function
//--------------------------------------------------------------------------
// $Id: multiply.h,v 1.1 2006-03-05 07:03:29 cbatten Exp $

// Simple C version
int multiply(int x, int y);

// Simple assembly version
int multiply_asm(int x, int y);
